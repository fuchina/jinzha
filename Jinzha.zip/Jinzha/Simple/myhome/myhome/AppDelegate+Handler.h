//
//  AppDelegate+Handler.h
//  myhome
//
//  Created by fudon on 2017/1/7.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (Handler)

- (void)handlerApplication:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;

- (void)configParts;

- (void)normalAction;

@end
