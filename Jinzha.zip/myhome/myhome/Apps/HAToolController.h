//
//  HAToolController.h
//  myhome
//
//  Created by FudonFuchina on 2016/12/3.
//  Copyright © 2016年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface HAToolController : FSBaseController

@end
