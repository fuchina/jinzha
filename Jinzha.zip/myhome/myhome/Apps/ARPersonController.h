//
//  ARPersonController.h
//  myhome
//
//  Created by fudon on 2016/11/1.
//  Copyright © 2016年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface ARPersonController : FSBaseController

@end
