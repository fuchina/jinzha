//
//  AppDelegate.h
//  myhome
//
//  Created by fudon on 2016/10/31.
//  Copyright © 2016年 fuhope. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

- (void)handleParts;
- (void)handleViews;

@end

